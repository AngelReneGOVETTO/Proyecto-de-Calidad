import 'package:flutter/material.dart';
import 'package:loginm/screens/checking_screen.dart';
import 'package:loginm/screens/login_screen.dart';
import 'package:loginm/screens/principal_screen.dart';
import 'package:loginm/screens/registro_screen.dart';
import 'package:loginm/services/auth_services.dart';
import 'package:loginm/services/notifications_services.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(AppState());
}

class AppState extends StatelessWidget {
  const AppState({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthServices()),
      ],
      child: MyApp(),
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login Demon',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
              seedColor: Color.fromARGB(255, 247, 230, 196)),
          useMaterial3: true),
      initialRoute: 'checking',
      routes: {
        'login': (_) => LoginScreen(),
        'register': (_) => RegistroScreen(),
        'home': (_) => PrincipalScreen(),
        'checking': (_) => CheckAuthScreen()
      },
      scaffoldMessengerKey: NotificationsServices.messengerKey,
    );
  }
}
