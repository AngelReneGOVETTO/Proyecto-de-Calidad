import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lista de Rectángulos',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: RectangleListScreen(),
    );
  }
}

class RectangleListScreen extends StatefulWidget {
  @override
  _RectangleListScreenState createState() => _RectangleListScreenState();
}

class _RectangleListScreenState extends State<RectangleListScreen> {
  List<Map<String, dynamic>> rectangles = [];

  void _addRectangle(String name, String description, File? image) {
    setState(() {
      rectangles.add({
        'name': name,
        'description': description,
        'image': image,
      });
    });
  }

  Future<void> _showAddRectangleDialog() async {
    String name = '';
    String description = '';
    File? imageFile;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: InputDecoration(labelText: 'Nombre del celular'),
                  onChanged: (value) {
                    name = value;
                  },
                ),
                TextField(
                  decoration: InputDecoration(labelText: 'Descripción'),
                  onChanged: (value) {
                    description = value;
                  },
                ),
                SizedBox(height: 10),
                GestureDetector(
                  onTap: () async {
                    final pickedFile = await ImagePicker()
                        .pickImage(source: ImageSource.gallery);
                    if (pickedFile != null) {
                      setState(() {
                        imageFile = File(pickedFile.path);
                      });
                    }
                  },
                  child: Container(
                    height: 100,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                    ),
                    child: imageFile != null
                        ? Image.file(imageFile!, fit: BoxFit.cover)
                        : Center(child: Text("Seleccionar imagen")),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    _addRectangle(name, description, imageFile);
                    Navigator.pop(context);
                  },
                  child: Text('Guardar'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showRectangleDetails(Map<String, dynamic> rectangle) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(rectangle['name']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(rectangle['description']),
            if (rectangle['image'] != null)
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: Image.file(rectangle['image']),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Rectángulos'),
      ),
      body: ListView.builder(
        itemCount: rectangles.length,
        itemBuilder: (context, index) {
          final rectangle = rectangles[index];
          return GestureDetector(
            onTap: () => _showRectangleDetails(rectangle),
            child: Container(
              margin: EdgeInsets.symmetric(vertical: 8.0),
              width: double.infinity,
              height: 100.0,
              color: Colors.blue.shade100,
              child: Center(
                child: Text(
                  rectangle['name'],
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddRectangleDialog,
        child: Icon(Icons.add),
      ),
    );
  }
}
